
(function(a){a(document).ready(function(){if(!a("html").hasClass("is-builder")){var b=!0;a(window).scroll(function(){b&&0!==document.documentElement.scrollTop&&80<=(document.documentElement.scrollTop+window.innerHeight)/document.documentElement.offsetHeight*100&&(a(".mbr-popup[data-on-scroll]").each(function(b,c){a(c).modal("show")}),b=!1)})}})})(jQuery);
